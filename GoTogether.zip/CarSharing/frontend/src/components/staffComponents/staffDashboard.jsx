/* Staff dashboard page/wrapper */
import React, { Component } from 'react';
import { Container, Col, Row } from 'react-bootstrap';
import UserServiceApi from '../../api/UserServiceApi';
import '../../styles/staffDashboard.css';

// define styles
const FunctionSelectedStyle = {
    borderBottom: "4px solid #009bde",
    color: "white"
};
const FunctionNotSelectedStyle = {
    color: "white"
};

export default class StaffDashboard extends Component {
    render() {
        const currentLocation = window.location.pathname;
        const isAdmin = UserServiceApi.isUserAdmin;
        return (
            <Container style={{ margin: "0", padding: "0", maxWidth: "100%" }}>
                <Row style={{ margin: "0" }}>
                    <Col className="sidenav" md={2}>
                        <h3>{isAdmin ? "Admin" : "Staff"} Functions</h3>
                        <p><a href="/staff" style={(currentLocation === "/staff") ? FunctionSelectedStyle : FunctionNotSelectedStyle}>Overview</a></p>
                        {
                            isAdmin &&
                            <>
                                <p><a href="/admin/signup" style={(currentLocation === "/admin/signup") ? FunctionSelectedStyle : FunctionNotSelectedStyle}>Create Account</a></p>
                                <p><a href="/admin/view/customers" style={(currentLocation === "/admin/customers") ? FunctionSelectedStyle : FunctionNotSelectedStyle}>View All Customers</a></p>
                                <p><a href="/admin/view/bookings" style={(currentLocation === "/admin/view/bookings") ? FunctionSelectedStyle : FunctionNotSelectedStyle}>View All Bookings</a></p>
                                <p><a href="/admin/view/location" style={(currentLocation === "/admin/view/location") ? FunctionSelectedStyle : FunctionNotSelectedStyle}>View All Trips</a></p>
                            </>
                        }
                    </Col>
                    <Col className="main" md={10} style={{ paddingTop: '5vh' }}>
                        {this.props.children}
                    </Col>
                </Row>
            </Container>
        )
    }
}
