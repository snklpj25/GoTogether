// JWT verification config
module.exports = {
    secretOrKey: "secret"
};
